# Visualization functions
import matplotlib.pyplot as plt

def plot_series(series, title='Time Series'):
    series.plot(title=title)
    plt.show()